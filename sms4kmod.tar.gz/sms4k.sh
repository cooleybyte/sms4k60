#!/bin/bash
echo  -----------------------------------------
 echo super mario sunshine 4k
echo ------------------------------------------
clear
sudo apt install p7zip-full -y
cls
cd ~/.local/share/
curl https://download1532.mediafire.com/mdobn8mpkfig/5u4xcpi8rftj2yf/dolphfold3.tar --output dolphfold3.tar
7z x dolphfold3.tar
chmod 777 dolphin-emu
cd ~/.local/share/dolphin-emu/Load/Textures/
curl -L -O https://github.com/quinton-ashley/Super_Mario_Sunshine_UHD_Texture_Pack/releases/latest/download/GMS.7z --output GMS.7z
7z x GMS.7z
pause