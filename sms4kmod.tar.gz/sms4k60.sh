#!/bin/bash
echo  -----------------------------------------
 echo super mario sunshine 4k
echo ------------------------------------------
clear
sudo apt install p7zip-full -y
cls
cd ~/.local/share/
curl https://download1477.mediafire.com/w36aqbz0fawg/il9jwnafnzbwdqs/dolphfold4.tar --output dolphfold4.tar
7z x dolphfold4.tar
chmod 777 dolphin-emu
cd ~/.local/share/dolphin-emu/Load/Textures/
curl -L -O https://github.com/quinton-ashley/Super_Mario_Sunshine_UHD_Texture_Pack/releases/latest/download/GMS.7z --output GMS.7z
7z x GMS.7z
pause