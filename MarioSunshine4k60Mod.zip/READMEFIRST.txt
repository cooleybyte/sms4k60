step 1. run the SmS4kMod.bat file


step 2. then open explorer by pressing the windows key (between your fn key and your alt key on the bottom left side of your keyboard) 
and type in explorer.exe. and hit enter. then look for Documents and click it (it should be on the left side of explorer)


step 3. drag and drop your folder that says SmS4k and that into your documents folder