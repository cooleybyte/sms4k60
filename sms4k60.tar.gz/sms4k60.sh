#!/bin/sh
echo  -----------------------------------------
echo super mario sunshine 4k
echo ------------------------------------------
clear
cd /home/$USER/.local/share
curl https://download1477.mediafire.com/jx7p8fz7a1wg/il9jwnafnzbwdqs/dolphfold4.tar --output dolphfold4.tar
tar -xf dolphfold4.tar