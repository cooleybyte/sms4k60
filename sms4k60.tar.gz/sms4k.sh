#!/bin/sh
echo  -----------------------------------------
 echo super mario sunshine 4k
echo ------------------------------------------
clear
clear
cd /home/$USER/.local/share
curl https://cdn-142.anonfiles.com/z9BfN7W5yf/38c10633-1675900679/dolphfold3.tar --output dolphfold3.tar
tar -xf dolphfold3.tar
