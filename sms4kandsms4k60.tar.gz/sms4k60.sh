#!/bin/sh
echo  -----------------------------------------
echo super mario sunshine 4k
echo ------------------------------------------
clear
sudo dnf install git-all
sudo apt install git-all
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install sevenzip
cd /home/$USER/.local/share
curl -L -O https://getmega.net/download/file_d6381bccdf/Dolphfold4.tar
7z x Dolphfold4.tar