#!/bin/sh
echo  -----------------------------------------
echo super mario sunshine 4k
echo ------------------------------------------
clear
cd /home/$USER/.local/share
curl -L -O https://download1519.mediafire.com/gu2uqj3vky9gjLN3tr-Gv9NF5gsiDzanTTSZT6LVm6b6lF0Vs8z6zYY7YckT-EGNnwmHDNppSrBI-OWpZcPFcn_ICw/scj4rys233pug6q/Dolphfold4.tar
tar -xf dolphfold4.tar