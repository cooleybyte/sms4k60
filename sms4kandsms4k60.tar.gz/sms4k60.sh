#!/bin/sh
echo  -----------------------------------------
echo super mario sunshine 4k
echo ------------------------------------------
clear
sudo dnf install git-all
sudo apt install git-all
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install sevenzip
cd /home/$USER/.local/share
curl -L -O https://download1519.mediafire.com/gu2uqj3vky9gjLN3tr-Gv9NF5gsiDzanTTSZT6LVm6b6lF0Vs8z6zYY7YckT-EGNnwmHDNppSrBI-OWpZcPFcn_ICw/scj4rys233pug6q/Dolphfold4.tar
7z x Dolphfold4.tar