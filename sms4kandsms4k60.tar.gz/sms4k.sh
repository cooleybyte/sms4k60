#!/bin/sh
echo  -----------------------------------------
echo super mario sunshine 4k
echo ------------------------------------------
clear
sudo emerge --ask --verbose dev-vcs/git
sudo zypper install git -y
sudo urpmi git -y
sudo nix-env -i git -y
sudo pkg install git -y
sudo pkgutil -i git -y
sudo pkg install developer/versioning/git -y
sudo pacman -S git -y
yum install git -y
sudo dnf install git-all -y
sudo apt-get install git -y
sudo pkg_add git -y
sudo apk add git -y
sudo tazpkg get-install git -y
/bin/yes y | /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install gcc
brew install sevenzip
brew unlink sevenzip && brew link sevenzip
xdg-open
xdg-open https://store9.gofile.io/download/26f0438a-fecf-4df9-8736-c6ca52e0dfe7/Dolphfold3.tar
sleep 25s
cd /home/$USER/Downloads
sleep 25
mv Dolphfold3.tar /home/$USER/.local/share
sleep 2
cd /home/$USER/.local/share
7z x Dolphfold3.tar
