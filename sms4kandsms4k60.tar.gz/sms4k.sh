#!/bin/sh
echo  -----------------------------------------
 echo super mario sunshine 4k
echo ------------------------------------------
clear
clear
sudo dnf install git-all
sudo apt install git-all
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install sevenzip
cd /home/$USER/.local/share
timeout 5 curl -L -O https://download948.mediafire.com/nsvsup0xwkbgJrY5oUs7XptKCFJX0f7Z4Zv8rVdR63bhwR7PfGQCgte--hjOL5I1fkf2_XIk5C85OLoGe2bAh_GiwA/a4js25ea3tovos4/Dolphfold3.tar
timeout 5 7z x Dolphfold3.tar
