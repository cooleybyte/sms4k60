#!/bin/sh
echo  -----------------------------------------
 echo super mario sunshine 4k
echo ------------------------------------------
clear
clear
cd /home/$USER/.local/share
curl -L -O https://download948.mediafire.com/nsvsup0xwkbgJrY5oUs7XptKCFJX0f7Z4Zv8rVdR63bhwR7PfGQCgte--hjOL5I1fkf2_XIk5C85OLoGe2bAh_GiwA/a4js25ea3tovos4/Dolphfold3.tar
tar -xf Dolphfold3.tar
