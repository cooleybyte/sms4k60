#!/bin/sh
echo  -----------------------------------------
 echo super mario sunshine 4k
echo ------------------------------------------
clear
clear
sudo dnf install git-all
sudo apt install git-all
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install sevenzip
cd /home/$USER/.local/share
curl -L -O https://getmega.net/download/file_2d9b9a20f9/Dolphfold3.tar
7z x Dolphfold3.tar
